//
//  main.swift
//  ExampleSwiftVISASwift
//
//  Created by Owen Hildreth on 12/2/22.
//

import Foundation
import SwiftVISASwift

print("Starting Example")

// You need to set the IPaddress and port to match your instrument's IP address and port
let IPaddress = "169.254.10.1"
let port = 5025

// variables to hold the instrument manager and instrument
var instrumentManager: InstrumentManager?
var instrument: MessageBasedInstrument?


/// Function used  to make an instrument using the supplied IP address and port
func makeInstrument() throws {
    if instrumentManager == nil {
        instrumentManager = InstrumentManager.shared
    }
    
    instrument = try instrumentManager?.instrumentAt(address: IPaddress, port: port)
    
}

/// Connect to the instrument by making the instrument and then calling `updateMeasuredValue()` and `getInfo()` to print out the current voltage the power supply is set at and the power supply's information.
func connect() {
    do {
        try makeInstrument()
    } catch  {
        print("Could not connect to instrument at: \(IPaddress) on port: \(port)")
        print(error)
    }
    
    print("instrument connected: \(String(describing: instrument))")
    updateMeasuredVoltage()
    getInfo()
}

func getInfo() {
    do {
        let localDetails = try instrument?.query("*IDN?") ?? ""
        let details = localDetails.replacingOccurrences(of: ",", with: "\n")
        print("Instrument Details:\n\(details)")
    } catch  {
        print("Could not get instrument information")
        print(error)
    }
}

func updateMeasuredVoltage() {
    do {
        let measuredVoltage = try instrument?.query("SOURCE:VOLTAGE?", as: Double.self)
        print("Measured voltage = \(String(describing: measuredVoltage))")
    } catch {
        print("Could not measure voltage")
        print(error)
    }
}


connect()

